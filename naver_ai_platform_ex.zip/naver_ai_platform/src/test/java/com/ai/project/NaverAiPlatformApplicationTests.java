package com.ai.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaverAiPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
