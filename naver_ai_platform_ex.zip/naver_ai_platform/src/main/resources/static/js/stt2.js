/**
 * stt.js
 */
 
 
 $(document).ready(function(){
 	$('#sttForm').on('submit', function(){
 		event.preventDefault();
 		
 		// 폼 데이터 읽어 오기
 		var formData = new FormData($('#sttForm')[0]);
 		
 		// 업로드된 파일명 알아오기
 		var fileName = $('#uploadFile').val().split("\\").pop();
 		
 		$.ajax({
 			type: "post",
 			url: "stt2",
 			enctype: "multipart/form-data",
 			data: formData,
 			processData: false, // multipart 사용하기 위한 필수
 			contentType: false,
 			success: function(result){
		 		$('#resultBox').html(result);
		 		$('#audioBox audio').attr('src', '/audio/' + fileName); // 경로 및 파일명 설정
		 		//$('#audioBox audio').prop('src', '/audio/' + fileName);
 			},
 			error: function(){
 				alert("전송 실패");
 			}
 		});	
 	});
 });